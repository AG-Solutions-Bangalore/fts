const donor_type = [
    "Member",
    "Donor",
    "Member+Donor",
    "None",
  ];
  export default donor_type ;