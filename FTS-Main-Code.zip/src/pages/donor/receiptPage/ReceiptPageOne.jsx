import React from 'react'

const ReceiptPageOne = () => {
  return (
    <div>ReceiptPageOne</div>
  )
}

export default ReceiptPageOne