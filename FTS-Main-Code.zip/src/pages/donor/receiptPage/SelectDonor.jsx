import React from 'react'

const SelectDonor = ({id}) => {
  return (
   
        <div>SelectDonor{id}</div>

  )
}

export default SelectDonor