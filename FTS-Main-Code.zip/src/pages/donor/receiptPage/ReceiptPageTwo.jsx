import React from 'react'

const ReceiptPageTwo = () => {
  return (
    <div>ReceiptPageTwo</div>
  )
}

export default ReceiptPageTwo