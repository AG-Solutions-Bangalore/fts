import React from 'react'

const ReceiptPageThree = () => {
  return (
    <div>ReceiptPageThree</div>
  )
}

export default ReceiptPageThree