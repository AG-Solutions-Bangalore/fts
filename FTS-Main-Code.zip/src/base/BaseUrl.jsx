const BASE_URL = "https://agsrb.online/api/public";

export default BASE_URL;
